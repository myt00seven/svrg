# alexnetLasagne
an implementation of alexnet using Lasagne
